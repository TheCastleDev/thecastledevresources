// Abrir la interfaz oculta al presionar el atajo
chrome.commands.onCommand.addListener((command) => {
  if (command === "open-config") {
    chrome.tabs.create({ url: "options.html" });
  }
});

// Escuchar cambios en la lista de bloqueados
chrome.storage.onChanged.addListener((changes) => {
  if (changes.sitiosBloqueados) {
    actualizarReglas(changes.sitiosBloqueados.newValue);
  }
});

function actualizarReglas(lista) {
  const reglas = lista.map((url, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: "block" },
    condition: { urlFilter: url, resourceTypes: ["main_frame"] }
  }));

  chrome.declarativeNetRequest.getDynamicRules(oldRules => {
    const oldIds = oldRules.map(r => r.id);
    chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: oldIds,
      addRules: reglas
    });
  });
}