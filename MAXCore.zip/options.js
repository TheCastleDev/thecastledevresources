const textarea = document.getElementById('lista');

// Cargar configuración
chrome.storage.local.get('sitiosBloqueados', (data) => {
  if (data.sitiosBloqueados) {
    textarea.value = data.sitiosBloqueados.join('\n');
  }
});

// Guardar con Ctrl+G
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && (e.key === 'g' || e.key === 'G')) {
    e.preventDefault();
    const texto = textarea.value;
    const dominios = texto.split('\n').filter(linea => linea.trim() !== '');
    
    chrome.storage.local.set({ sitiosBloqueados: dominios }, () => {
      // Feedback visual sutil (parpadeo del cursor o título)
      const originalTitle = document.title;
      document.title = "Saving...";
      setTimeout(() => {
        document.title = originalTitle;
      }, 500);
    });
  }
});

// Mantener el foco siempre en el textarea
textarea.focus();
document.addEventListener('click', () => textarea.focus());